<?php
if (is_file('sana.txt')){
  $son = file_get_contents('./sana.txt', true);
  file_put_contents('./sana.txt', $son+1);
}else{
  file_put_contents('./sana.txt', 0);
}
?>